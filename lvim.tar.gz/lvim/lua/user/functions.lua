function P(object)
	print(vim.inspect(object))
end
